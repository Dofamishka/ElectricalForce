<?php
var_damp( $_POST );
?>